# Compiling Plugins

In our final project of the course, we'll learn to convert one of our Python plugins to a C++ plugin.

## Reference Materials

### Chad Vernon 

Chad has a github page with the CMake files we'll be basing our project from.

https://github.com/chadmv/cgcmake

He also has a Youtube series which explains how CMake works:

https://www.youtube.com/watch?v=2mUOt_F2ywo&list=PL_RMNSHxKvdUFTdl12WumiqnNWLn4LDQj